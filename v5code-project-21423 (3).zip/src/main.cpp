/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       victoriang                                                */
/*    Created:      Wed Sep 07 2022                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// frontRightMotor      motor         17              
// frontLeftMotor       motor         18              
// inertia              inertial      13              
// lineTrackerBL        line          A               
// lineTrackerBR        line          B               
// lineTrackerFL        line          C               
// lineTrackerFR        line          D               
// lineTrackerMB        line          E               
// lineTrackerMF        line          F               
// rollerSpinner        motor         9               
// backRightMotor       motor         1               
// backLeftMotor        motor         8               
// Controller1          controller                    
// pneumatic            digital_out   H               
// yEncoder             rotation      7               
// xEncoder             rotation      10              
// indexer              motor         14              
// opticalSensor        optical       21              
// flywheel             motor         4               
// intake               motor         6               
// pneum2               digital_out   G               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include <cmath>
#include "points.h"
#include "pid.h"

using namespace vex;

competition Competition;

bool isTracking = false;

//270, 30
//240, 600, 120
float robotY;
float robotX;

int yEncoderLast;
int xEncoderLast;
int lastRot;

PID drivePid = PID(.15, .01, .09);
PID drivePidSlow = PID(.15, 0, 0);
PID turnPid = PID(1,0,1);

double getRegularRotation()
{
  double curRot = inertia.rotation();
  
  //rotation value divided by 360 to get integer amt of rotations
  int times = (int)(curRot / 360);
  //inertia large degree value subtracted by total degree of rotations
  curRot -= (360 * times);

  return curRot;
}

void makeTurn(int amount, int speed)
{
  inertia.setRotation(0,degrees);
  
  while(inertia.rotation(degrees) < amount){
    frontLeftMotor.setVelocity(speed,rpm);
    frontRightMotor.setVelocity(speed,rpm);
    backRightMotor.setVelocity(speed,rpm);
    backLeftMotor.setVelocity(speed,rpm);

    frontLeftMotor.spin(fwd);
    frontRightMotor.spin(fwd);
    backRightMotor.spin(fwd);
    backLeftMotor.spin(fwd);
  }
}

//ex 270
void turnTo(int degree)
{
  //ex 30
  double cur = getRegularRotation();

  //270 - 30 = 240
  double distOne = degree - cur;
  //630 - 30 = 600
  double distTwo = (degree + 360) - cur;
  //390 - 270 = 120
  double distThree = (cur + 360) - degree;
 
}

int spinIndexerFWD(){
  // while(true){
  //   indexer.spin(fwd);
  //   wait(0.25 , sec);
  //   indexer.stop();
  //   wait(0.5 , sec);
  // }
  indexer.spin(vex::directionType::fwd,100,vex::velocityUnits::pct);
  return 0;
}

int spinIndexerREV(){
  indexer.spin(reverse);
  return 0;
}

int track()
{
  robotX = 0.0;
  robotY = 0.0;

  xEncoderLast = 0;
  yEncoderLast = 0;

  xEncoder.resetPosition();
  xEncoder.resetPosition();
  yEncoder.resetPosition();
  yEncoder.resetPosition();

  while(true)
  {
    int curX = xEncoder.position(degrees);
    int curY = yEncoder.position(degrees);

    double yDist = yEncoderLast - yEncoder.position(degrees);
    double xDist = xEncoderLast - xEncoder.position(degrees);

    double curRot = inertia.rotation();
    Brain.Screen.setCursor(1,1);
    Brain.Screen.print("I: %f", curRot);

    double turnDist = curRot - lastRot;
    if(fabs(turnDist) < 1)
    {
      turnDist = 0;
    }
    if(fabs(yDist) < 1)
    {
      yDist = 0;
    }
    if(fabs(xDist) < 1)
    {
      xDist = 0;
    }

    yEncoderLast = curY;
    xEncoderLast = curX;
    lastRot = curRot;

    double rot = getRegularRotation();

    //convert to radians
    double rotRad = rot * M_PI / 180;

    //Controller1.Screen.clearScreen();
    //x coordinate goes up from x encoder when oriented straight (cos0 = 1) and y encoder value when turned (sin90 = 1)
    robotX += (xDist * cos(rotRad)) + (yDist * sin(rotRad));
    Brain.Screen.setCursor(3,1);
    Brain.Screen.print("X: %f", robotX);
    Brain.Screen.setCursor(4,1);
    Brain.Screen.print("XDist: %f", xDist);
    Brain.Screen.setCursor(5,1);
    Brain.Screen.print("YDist: %f", yDist);
    robotY += (xDist * sin(rotRad)) + (yDist * cos(rotRad));
    Brain.Screen.setCursor(6,1);
    Brain.Screen.print("Y: %f", robotY);

    wait(20, msec);
    Brain.Screen.clearScreen();
  }
  return 0;
}

void moveY(int amount, double speed)
{
  yEncoder.resetPosition();

  do
  {
    double s = drivePid.calculate(yEncoder.position(degrees), amount);

    frontLeftMotor.setVelocity(speed * s,rpm);
    frontRightMotor.setVelocity(speed * s,rpm);
    backRightMotor.setVelocity(speed * s,rpm);
    backLeftMotor.setVelocity(speed * s,rpm);

    frontLeftMotor.spin(reverse);
    frontRightMotor.spin(reverse);
    backRightMotor.spin(reverse);
    backLeftMotor.spin(reverse);

  } while(abs((int)drivePid.error) > 5);

  frontLeftMotor.setStopping(brake);
  frontRightMotor.setStopping(brake);
  backRightMotor.setStopping(brake);
  backLeftMotor.setStopping(brake);

  frontLeftMotor.stop();
  frontRightMotor.stop();
  backRightMotor.stop();
  backLeftMotor.stop();
}

void moveYSlow(int amount, double speed)
{
  yEncoder.resetPosition();

  do
  {
    double s = drivePidSlow.calculate(yEncoder.position(degrees), amount);

    frontLeftMotor.setVelocity(speed * s,rpm);
    frontRightMotor.setVelocity(speed * s,rpm);
    backRightMotor.setVelocity(speed * s,rpm);
    backLeftMotor.setVelocity(speed * s,rpm);

    frontLeftMotor.spin(fwd);
    frontRightMotor.spin(fwd);
    backRightMotor.spin(fwd);
    backLeftMotor.spin(fwd);

  } while(abs((int)drivePid.error) > 5);

  frontLeftMotor.setStopping(brake);
  frontRightMotor.setStopping(brake);
  backRightMotor.setStopping(brake);
  backLeftMotor.setStopping(brake);

  frontLeftMotor.stop();
  frontRightMotor.stop();
  backRightMotor.stop();
  backLeftMotor.stop();
}

void moveX(int amount, double speed)
{
  xEncoder.resetPosition();

  do
  {
    double s = drivePid.calculate(xEncoder.position(degrees), amount);

    frontLeftMotor.setVelocity(speed * s,rpm);
    frontRightMotor.setVelocity(speed * s,rpm);
    backRightMotor.setVelocity(speed * s,rpm);
    backLeftMotor.setVelocity(speed * s,rpm);

    frontLeftMotor.spin(reverse);
    frontRightMotor.spin(fwd);
    backRightMotor.spin(reverse);
    backLeftMotor.spin(fwd);

  } while(abs((int)drivePid.error) > 5);

  frontLeftMotor.setStopping(brake);
  frontRightMotor.setStopping(brake);
  backRightMotor.setStopping(brake);
  backLeftMotor.setStopping(brake);

  frontLeftMotor.stop();
  frontRightMotor.stop();
  backRightMotor.stop();
  backLeftMotor.stop();
}

void moveOdom(int finalY, double speed){
    do{
    double s = drivePid.calculate(robotY, finalY);

    frontLeftMotor.setVelocity(speed * s,rpm);
    frontRightMotor.setVelocity(speed * s,rpm);
    backRightMotor.setVelocity(speed * s,rpm);
    backLeftMotor.setVelocity(speed * s,rpm);

    frontLeftMotor.spin(fwd);
    frontRightMotor.spin(fwd);
    backRightMotor.spin(fwd);
    backLeftMotor.spin(fwd);

  } while(abs((int)drivePid.error) > 5);
}

void turnTo(int amount, double speed)
{
  inertia.setRotation(0,degrees);

  do
  {
    double s = turnPid.calculate(inertia.rotation(degrees), amount);

    frontLeftMotor.setVelocity(speed * s,rpm);
    frontRightMotor.setVelocity(-speed * s,rpm);
    backRightMotor.setVelocity(-speed * s,rpm);
    backLeftMotor.setVelocity(speed * s,rpm);

    frontLeftMotor.spin(reverse);
    frontRightMotor.spin(fwd);
    backRightMotor.spin(reverse);
    backLeftMotor.spin(fwd);
  } while(abs((int)turnPid.error) > 7);

  frontLeftMotor.setStopping(brake);
  frontRightMotor.setStopping(brake);
  backRightMotor.setStopping(brake);
  backLeftMotor.setStopping(brake);

  frontLeftMotor.stop();
  frontRightMotor.stop();
  backRightMotor.stop();
  backLeftMotor.stop();
}

void PIDdrive(double inches , double minSpeed , double maxSpeed) {
 
    frontRightMotor.resetPosition();
    frontLeftMotor.resetPosition();
    backRightMotor.resetPosition();
    backLeftMotor.resetPosition();
 
    double targetDegrees = (inches*360)/(4*3.14);  // 4 inch wheel
   
    double motorValue = frontRightMotor.position(degrees);

    double error = 0.0;

    double lastError = targetDegrees - motorValue;
 
    double motorPower;
 
    double kP = .35;
 
    int dT = 20;
 
    while(true) {
 
        motorValue = frontRightMotor.position(degrees);
 
        error = targetDegrees - motorValue; 

        if(fabs(error) < 10) {
          kP = 0;

          frontRightMotor.stop();
          frontLeftMotor.stop();
          backRightMotor.stop();
          backLeftMotor.stop();

          return;
        }
 
        motorPower = (error * kP);           //update motor powers

        if (motorPower < minSpeed && motorPower > 0)
        {
          motorPower = minSpeed;
        }
        if(motorPower > -(minSpeed) && motorPower < 0){
          motorPower = -(minSpeed);
        }

        if (motorPower > maxSpeed)
        {
          motorPower = maxSpeed;
        }
        if(motorPower < -(maxSpeed)){
          motorPower = -(maxSpeed);
        }

        inertia.calibrate();

        frontRightMotor.setVelocity(motorPower - (inertia.rotation(degrees) / 2),rpm);
        frontLeftMotor.setVelocity(motorPower + (inertia.rotation(degrees) / 2),rpm);
        backRightMotor.setVelocity(motorPower - (inertia.rotation(degrees) / 2),rpm);
        backLeftMotor.setVelocity(motorPower + (inertia.rotation(degrees) / 2),rpm);

        frontRightMotor.spin(forward);
        frontLeftMotor.spin(forward);
        backRightMotor.spin(forward);
        backLeftMotor.spin(forward);
 
        lastError = error;

        this_thread::sleep_for(dT);
    }
    frontRightMotor.stop(); //after loop is broken, stop motors
    frontLeftMotor.stop();
    backRightMotor.stop();
    backLeftMotor.stop();
}

void PIDturn(double degs)
{
  frontRightMotor.resetPosition();
  frontLeftMotor.resetPosition();
  backRightMotor.resetPosition();
  backLeftMotor.resetPosition();

  double targetDegrees = (degs*360)/(4*3.1415*11);

  double motorValue = frontRightMotor.position(degrees);

  double error = 0.0;

  double lastError = targetDegrees - motorValue;

  double motorPower;

  double kP = .35;

  int dT = 20;

  while(true){
    motorValue = frontRightMotor.position(degrees);
    
    error = targetDegrees - motorValue;

    if(fabs(error) < 10){
      kP = 0;

      frontRightMotor.stop();
      frontLeftMotor.stop();
      backRightMotor.stop();
      backLeftMotor.stop();

      inertia.calibrate();
      
      return;
    }

    motorPower = (error * kP);

    if (motorPower < 20 && motorPower > 0)
    {
      motorPower = 20;
    }
    if(motorPower > -20 && motorPower < 0){
      motorPower = -20;
    }

    frontRightMotor.setVelocity(motorPower * .5,rpm);
    frontLeftMotor.setVelocity(motorPower * .5,rpm);
    backRightMotor.setVelocity(motorPower * .5,rpm);
    backLeftMotor.setVelocity(motorPower * .5,rpm);

    frontRightMotor.spin(reverse);
    frontLeftMotor.spin(forward);
    backRightMotor.spin(reverse);
    backLeftMotor.spin(forward);

    lastError = error;

    this_thread::sleep_for(dT);
  }
  frontRightMotor.stop();
  frontLeftMotor.stop();
  backRightMotor.stop();
  backLeftMotor.stop();

  inertia.calibrate();
}

/*
Test: pass true in as parameter to show that we want to spin the roller to red
have the roller at blue and the motor should spin
manually move the roller to red and make sure it stops

optical sensor value blue: 115
optical sensor value red: 15
*/
void detectColor(bool targetRed){
  if(targetRed)
  {

    while(!opticalSensor.isNearObject())
    {
      backLeftMotor.spin(vex::directionType::rev,10,vex::velocityUnits::pct);
      backRightMotor.spin(vex::directionType::rev,10,vex::velocityUnits::pct);
      frontLeftMotor.spin(vex::directionType::rev,10,vex::velocityUnits::pct);
      frontRightMotor.spin(vex::directionType::rev,10,vex::velocityUnits::pct);
    }

    backLeftMotor.spin(vex::directionType::rev,10,vex::velocityUnits::pct);
    backRightMotor.spin(vex::directionType::rev,10,vex::velocityUnits::pct);
    frontLeftMotor.spin(vex::directionType::rev,10,vex::velocityUnits::pct);
    frontRightMotor.spin(vex::directionType::rev,10,vex::velocityUnits::pct);

    wait(.1, sec);

    backLeftMotor.stop(vex::brakeType::hold);
    backRightMotor.stop(vex::brakeType::hold);
    frontLeftMotor.stop(vex::brakeType::hold);
    frontRightMotor.stop(vex::brakeType::hold);

    rollerSpinner.spin(vex::directionType::rev,100,vex::velocityUnits::pct);

    wait(.5 , sec);

    rollerSpinner.stop();

    wait(.5 , sec);
  }
  else
  {

    while(!opticalSensor.isNearObject())
    {
      backLeftMotor.spin(vex::directionType::rev,10,vex::velocityUnits::pct);
      backRightMotor.spin(vex::directionType::rev,10,vex::velocityUnits::pct);
      frontLeftMotor.spin(vex::directionType::rev,10,vex::velocityUnits::pct);
      frontRightMotor.spin(vex::directionType::rev,10,vex::velocityUnits::pct);
    }

    backLeftMotor.spin(vex::directionType::rev,10,vex::velocityUnits::pct);
    backRightMotor.spin(vex::directionType::rev,10,vex::velocityUnits::pct);
    frontLeftMotor.spin(vex::directionType::rev,10,vex::velocityUnits::pct);
    frontRightMotor.spin(vex::directionType::rev,10,vex::velocityUnits::pct);

    wait(.15, sec);

    backLeftMotor.stop(vex::brakeType::hold);
    backRightMotor.stop(vex::brakeType::hold);
    frontLeftMotor.stop(vex::brakeType::hold);
    frontRightMotor.stop(vex::brakeType::hold);

    rollerSpinner.spin(vex::directionType::rev,100,vex::velocityUnits::pct);

    wait(.15 , sec);

    rollerSpinner.stop();

    wait(.5 , sec);
  }
}

/*
Test: make sure you can differentiate colors and when sensor is near something or not
*/
void buzzForColor()
{
  Controller1.Screen.clearScreen();
  while(true)
  {
    Brain.Screen.print(opticalSensor.hue());
    wait(.1,sec);
    Brain.Screen.clearLine();

    Controller1.Screen.print(opticalSensor.hue());
    wait(.1,sec);
    Controller1.Screen.clearLine();
    if(opticalSensor.isNearObject())
    {
      //red
      if(opticalSensor.hue() < 100 || opticalSensor.hue() > 300)
      {
        Controller1.rumble("--");
      }
      else{
        Controller1.rumble("...");
      }
    }
  }
}

void basketTurn(int dir){
  //Tape: 10
  //Field: 6
  if(dir == 1){
    //turn until on tape (one being used to line up)
    while(lineTrackerBR.reflectivity() < 9){
      frontRightMotor.spin(reverse);
      frontLeftMotor.spin(fwd);
      backRightMotor.spin(reverse);
      backLeftMotor.spin(fwd);
    }
  }
  else if(dir == 0){
    //two being used to line up
    while(lineTrackerMF.reflectivity() < 9 && lineTrackerMB.reflectivity() < 9){
      frontRightMotor.spin(reverse); 
      frontLeftMotor.spin(fwd);
      backRightMotor.spin(reverse); 
      backLeftMotor.spin(fwd);
    }
  }
  else{
    //one being used to line up
    while(lineTrackerBL.reflectivity() < 9){
      frontRightMotor.spin(fwd);
      frontLeftMotor.spin(reverse);
      backRightMotor.spin(fwd);
      backLeftMotor.spin(reverse);
    }
  }
}

void shootDisc(int flywheelSpeed, int numDiscsShooting){
  flywheel.spin(vex::directionType::fwd,flywheelSpeed,vex::velocityUnits::pct);
  wait(3, sec);
  int count = 0;
  while(count < numDiscsShooting){
    indexer.spin(vex::directionType::fwd,-150,vex::velocityUnits::pct);
    //intake.spin(vex::directionType::fwd,100,vex::velocityUnits::pct);
    wait(2000 , msec);
    indexer.stop();
    //intake.stop();
    wait(1.8 , sec);
    count ++;
    // Controller1.Screen.setCursor(5 , 5);
    // Controller1.Screen.print(count);
  }
  flywheel.stop(brakeType::coast);
  indexer.stop();

}

void pre_auton(void) {
  vexcodeInit();

  inertia.calibrate();
  while (inertia.isCalibrating()) 
  {
    wait(3, seconds);
  }

  Controller1.rumble(rumbleShort);
  pneumatic.set(0);

}

void longAuton(){
  thread myThread = thread(track);
  //moveX(920, 1);
  moveY(1350,1);
  turnTo(87,1);
  detectColor(false); //blue top
  moveY(-110,1);
  turnTo(13,1);
  shootDisc(80, 5);
}

void shortAuton(){
  thread myThread = thread(track);
  //moveX(920, 1);
  // moveOdom(-1510,1);
  // turnTo(-90,1);
  detectColor(false); //blue top
  //rollerSpinner.spin(vex::directionType::rev,100,vex::velocityUnits::pct);
  wait(.5 , sec);
  rollerSpinner.stop();
  wait(.5 , sec);
  moveY(-200,1);
  turnTo(-8,1);
  shootDisc(75, 5);
}

void skillsAuton(){
  thread myThread = thread(track);
  //detectColor(true); //red top

  flywheel.spin(vex::directionType::fwd,72,vex::velocityUnits::pct);
  moveY(185,1);
  rollerSpinner.spin(vex::directionType::fwd,100,vex::velocityUnits::pct);
  wait(250, msec);
  rollerSpinner.stop();
  moveY(-20,1);
  turnTo(-14, 0.3);
  //shootDisc(70, 1);
  turnTo(22, 0.3);
  moveY(-630,1);
  intake.spin(reverse, 100, pct);
  turnTo(100,0.4);
  moveY(790,1);
  
  rollerSpinner.spin(vex::directionType::fwd,100,vex::velocityUnits::pct);
  wait(150, msec);
  rollerSpinner.stop();


  // intake.spin(vex::directionType::rev,100,vex::velocityUnits::pct);
  // rollerSpinner.spin(vex::directionType::fwd,100,vex::velocityUnits::pct);
  // moveY(-1280,1);
  // wait(2, sec);
  // intake.stop();
  // rollerSpinner.stop();
  // turnTo(120,1);
  // detectColor(true);
  // moveY(-50,1);
  // turnTo(-90,1);
  // moveY(1270,1);
  // shootDisc(60);
  // moveY(3000,1);
  // turnTo(90,1);
  // // intake.spin(vex::directionType::rev,100,vex::velocityUnits::pct);
  // rollerSpinner.spin(vex::directionType::fwd,100,vex::velocityUnits::pct);
  // moveY(3000,1);
  // turnTo(50,1);
  // // intake.stop();
  // rollerSpinner.stop();
  // detectColor(true);
  // // shootDisc();
  // pneumatic.set(true);
  // //pneum2.set(true);
}

int timesPressed = 0;
void flywheelHoldFaster(){
timesPressed++;
if(timesPressed % 2 == 0){
flywheel.stop(brakeType::coast);
}
else{
flywheel.spin(forward, 64, pct);
}
timesPressed = 0;
}
void flywheelHoldSlower(){
timesPressed++;
if(timesPressed % 2 == 0){
flywheel.stop(brakeType::coast);
}
else{
flywheel.spin(forward, 50, pct);
}
timesPressed = 0;
}

int spinRollerRed(){
  while(opticalSensor.hue() < 70)
    {
      rollerSpinner.spin(fwd);
    }
    return 0;
}

int spinRollerBlue(){
  while(opticalSensor.hue() > 70)
    {
      rollerSpinner.spin(fwd);
    }
    return 0;
}

int spinIndexerDefault(){
indexer.spin(fwd, 200, pct);
wait(450,msec);
indexer.stop();
return 0;
}

int spinIndexerShoot(){
indexer.spin(reverse, 200, pct);
wait(450,msec);
indexer.stop();
return 0;
}

int intakeSpeed = 200;
int rolyPolySpeed = 50;
int rollerSpeed = 200;
int indexerSpeed = 5;
void usercontrol(void){

  // Controller1.Screen.setCursor(1,1);
  // bool oneOpen = false; 
  // bool twoOpen = false;
  // int speed = 80;
  // int gradStop = -1;

  // while(true)
  // {
  //   flywheel.spin(vex::directionType::fwd,speed,vex::velocityUnits::pct);

  //     int dir = 0;
  //     if(Controller1.Axis3.position(pct) > 0){
  //       dir = 1;
  //     }
  //     else{
  //       dir = -1;
  //     }

  //     if(Controller1.Axis3.position(pct) == 0 && gradStop == -1){
  //       gradStop = 1;
  //     }
  //     else if(Controller1.Axis3.position(pct) != 0){
  //       gradStop = -1;
  //     }

  //     double rightPower = (double)((.8 * (Controller1.Axis3.position(pct) + gradStop * dir)) - (.5 * Controller1.Axis1.position(pct)));
  //     double leftPower = (double)((.8 * (Controller1.Axis3.position(pct) + gradStop * dir)) + (.5 * Controller1.Axis1.position(pct)));

  //     if(gradStop > 0){
  //       gradStop -= 0.15;
  //     }

  //     frontRightMotor.spin(fwd , rightPower, velocityUnits::pct);
  //     frontLeftMotor.spin(fwd , leftPower, velocityUnits::pct);
  //     backRightMotor.spin(fwd , rightPower, velocityUnits::pct);
  //     backLeftMotor.spin(fwd , leftPower, velocityUnits::pct);

  //     if(Controller1.ButtonR2.pressing())
  //     {
  //       rollerSpinner.spin(vex::directionType::fwd,60,pct);
  //       intake.spin(vex::directionType::rev,100000000000,volt);
  //     }
  //     else if(Controller1.ButtonR1.pressing())
  //     {
  //       rollerSpinner.spin(vex::directionType::rev,60,pct);
  //       intake.spin(vex::directionType::fwd,1000000000,volt);
  //       // flywheel.stop(vex::brakeType::hold);
  //     }
  //     else
  //     {
  //       rollerSpinner.stop(vex::brakeType::hold);
  //       intake.stop(vex::brakeType::hold);
  //       // flywheel.spin(vex::directionType::fwd,speed,vex::velocityUnits::pct);
  //     }

  //     if(Controller1.ButtonUp.pressing())
  //     {
  //       thread myThread = thread(spinIndexerFWD);
  //     }
  //     else if(Controller1.ButtonDown.pressing())
  //     {
  //       thread myThread = thread(spinIndexerREV);
  //     }
  //     else
  //     {
  //       indexer.stop(vex::brakeType::hold);
  //     }
  //     if(Controller1.ButtonRight.pressing())
  //     {
  //       flywheel.spin(vex::directionType::fwd,speed,vex::velocityUnits::pct);
  //     }
  //     if(Controller1.ButtonLeft.pressing())
  //     {
  //       speed -= 20;
  //       if(speed < 40)
  //       {
  //         speed = 80;
  //       }
  //     }
  //     Controller1.Screen.print(speed);
  //     Controller1.Screen.clearLine();
  //     if(Controller1.ButtonA.pressing())
  //     {
  //       thread spin = thread(spinRollerRed);
  //     }
  //     else if(Controller1.ButtonY.pressing())
  //     {
  //       thread spin = thread(spinRollerBlue);
  //     }
  //     if(Controller1.ButtonX.pressing() && Controller1.ButtonR1.pressing())
  //     {
  //       //right pneum
  //       oneOpen = true;
  //     }
  //     else if(Controller1.ButtonB.pressing() && Controller1.ButtonR1.pressing())
  //     {
  //       //left pneum
  //       twoOpen = true;
  //     }
  //     pneumatic.set(oneOpen);
  //     //pneum2.set(twoOpen);
  // }


// User control code here, inside the loop
// void flywheelHold(){
//   flywheel.spin(vex::directionType::fwd, flywheelSpeed, pct);
// }
//Controller1.ButtonR1.pressed(flywheelHoldFaster);
//Controller1.ButtonR2.pressed(flywheelHoldSlower);
//vex::digital_out pneu = vex::digital_out(Brain.ThreeWirePort.B);
//pneumatic1.set(false);
wait(100,msec);
//double turnimportance = 0.5;
while(1){

int fwdcont = Controller1.Axis3.position(percent);
int sidecont = Controller1.Axis4.position(percent);
int turncont = Controller1.Axis1.position(percent);

frontLeftMotor.spin(reverse, fwdcont -sidecont- turncont, velocityUnits::pct);
backLeftMotor.spin(reverse, fwdcont+sidecont+turncont, velocityUnits::pct);
frontRightMotor.spin(reverse, fwdcont+sidecont- turncont, velocityUnits::pct);
backRightMotor.spin(reverse, fwdcont-sidecont+turncont, velocityUnits::pct);


if(Controller1.ButtonX.pressing()){
thread myThread = thread(spinIndexerDefault);
}
else if(Controller1.ButtonA.pressing()){
thread myThread2 = thread(spinIndexerShoot);
}
else{
indexer.stop();
}

if(Controller1.ButtonDown.pressing()){
flywheel.stop(brakeType::coast);
}
else{
Controller1.ButtonR1.pressed(flywheelHoldFaster);
Controller1.ButtonR2.pressed(flywheelHoldSlower);
}

if(Controller1.ButtonL1.pressing()){
intake.spin(forward, intakeSpeed, pct);
rollerSpinner.spin(forward, rollerSpeed, pct);
}
else if(Controller1.ButtonL2.pressing()){
intake.spin(reverse, intakeSpeed, pct);
rollerSpinner.spin(reverse, rollerSpeed, pct);
}
else{
intake.stop();
rollerSpinner.stop();
}

if(Controller1.ButtonA.pressing()){
spinIndexerShoot();
}
else if(Controller1.ButtonX.pressing()){
spinIndexerDefault();
}
else{
indexer.stop();
}
}
// if(Controller1.ButtonRight.pressing()){
// pneu.set(true);
// }
// else {
// pneu.set(false);
// }

if(Controller1.ButtonRight.pressing()){
pneumatic = 1;
}
else {
pneumatic = 0;
}

}

int main() {

  Competition.autonomous(skillsAuton);


  Competition.drivercontrol(usercontrol);

  pre_auton();

  while (true) {
    wait(100, msec);
  }
}