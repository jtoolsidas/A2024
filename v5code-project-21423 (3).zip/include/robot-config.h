using namespace vex;

extern brain Brain;

// VEXcode devices
extern motor frontRightMotor;
extern motor frontLeftMotor;
extern inertial inertia;
extern line lineTrackerBL;
extern line lineTrackerBR;
extern line lineTrackerFL;
extern line lineTrackerFR;
extern line lineTrackerMB;
extern line lineTrackerMF;
extern motor rollerSpinner;
extern motor backRightMotor;
extern motor backLeftMotor;
extern controller Controller1;
extern digital_out pneumatic;
extern rotation yEncoder;
extern rotation xEncoder;
extern motor indexer;
extern optical opticalSensor;
extern motor flywheel;
extern motor intake;
extern digital_out pneum2;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );