/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// leftFrontMotor       motor         19              
// rightFrontMotor      motor         13              
// rightBackMotor       motor         18              
// leftBackMotor        motor         6               
// rightTopMotor        motor         12              
// leftTopMotor         motor         4               
// intake               motor         10              
// catapult             motor         7               
// pneumatic            digital_out   A               
// pneu2                digital_out   B               
// fourpneu             digital_out   C               
// inertia              inertial      5               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"
#include <math.h>
using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

void forwardPIDD(float setpoint) {
  float error = setpoint - leftBackMotor.position(degrees);
  float amt;
  float i = 1;
  double kP = 0.03;
  while (fabs(error) > i) {
    error = setpoint - leftBackMotor.position(degrees);
    amt = error * kP;
    Brain.Screen.printAt(60, 40, "%f", amt);
    Brain.Screen.printAt(60, 80, "%f", error);
    Brain.Screen.printAt(60, 15, "%f", leftBackMotor.position(degrees));
    leftFrontMotor.spin(fwd);
    rightFrontMotor.spin(fwd);
    rightBackMotor.spin(fwd);
    leftBackMotor.spin(fwd);
  }
  Brain.Screen.clearScreen();
  Brain.Screen.printAt(60, 15, "%f", leftBackMotor.position(degrees));
  leftFrontMotor.stop(coast);
  rightFrontMotor.stop(coast);
  rightBackMotor.stop(coast);
  leftBackMotor.stop(coast);
}

/*void driveDistance(int dist)
{
	nMotorEncoder[drive_LF] = 0; // reset the ime values to 0
	nMotorEncoder[drive_RF] = 0;
	driveLastError = 0; // update driveLastError

	driveTarget = fabs(dist/(WHEEL_DIAM*PI) * ENCODER_TICKS); // convert distance into encoder ticks. WHEEL_DIAM and ENCODER_TICKS set in globals
	driveError = driveTarget - fabs(nMotorEncoder[drive_LF]); // initial error calculation

	while (fabs(driveError) > DRIVE_ERROR_THRESH) // while more than DRIVE_ERROR_THRESH from target
	{
		driveError = driveTarget - fabs(nMotorEncoder[drive_LF]); // update error value

		int drivePower = sgn(dist) * (drivePD_Kp * driveError) + (drivePD_Kd * (driveError - driveLastError)); // initial PD power calculation

		drivePower = fabs(drivePower) > DRIVE_MAX_PWR ? sgn(drivePower) * DRIVE_MAX_PWR : drivePower; // limit power if calc is over max

		// drive straight power modifier
		int rDiff = fabs(nMotorEncoder[drive_LF]) - fabs(nMotorEncoder[drive_RF]); // check for right encoder difference
		int rMod = sgn(rDiff)*drivePower*.1; 					// rMod = 10% drivePower in the direction of rDiff

		set_drivePower( drivePower , drivePower + rMod );

		driveLastError = driveError; // update driveLastError

		wait1Msec(25);
	}

	set_drivePower( 0 , 0 ); // stop motors after target is reached

} */

void setSpeed() {
  leftFrontMotor.setVelocity(10, pct);
  rightFrontMotor.setVelocity(10, pct);;
  leftBackMotor.setVelocity(10, pct);;
  rightBackMotor.setVelocity(10, pct);;
}
void clearmotors () {
  leftFrontMotor.resetPosition();
  rightFrontMotor.resetPosition();
  leftBackMotor.resetPosition();
  rightBackMotor.resetPosition();
}

void turnPIDD(float setpoint) {
  float error = setpoint - leftBackMotor.position(degrees);
  float amt;
  float i = 1;
  double kP = 0.3;
  while (fabs(error) > i) {
    error = setpoint - leftBackMotor.position(degrees);
    amt = error * kP;
    Brain.Screen.printAt(30, 15, "%f", leftBackMotor.position(degrees));
    leftFrontMotor.spinFor(fwd, amt, degrees);
    rightFrontMotor.spinFor(reverse, amt, degrees);
    rightBackMotor.spinFor(reverse, amt, degrees);
    leftBackMotor.spinFor(fwd, amt, degrees);
  }
  Brain.Screen.clearScreen();
  Brain.Screen.printAt(60, 15, "%f", leftBackMotor.position(degrees));
  leftFrontMotor.stop(coast);
  rightFrontMotor.stop(coast);
  rightBackMotor.stop(coast);
  leftBackMotor.stop(coast);
}

void drfwd(int amt, int spd) {
    leftFrontMotor.setVelocity(spd,rpm);
    rightFrontMotor.setVelocity(spd,rpm);
    rightBackMotor.setVelocity(spd,rpm);
    leftBackMotor.setVelocity(spd,rpm);

    leftFrontMotor.spinFor(forward, amt, degrees);
    rightFrontMotor.spinFor(forward, amt, degrees);
    rightBackMotor.spinFor(forward, amt, degrees);
    leftBackMotor.spinFor(forward, amt, degrees);
}

void drrev(int amt, int spd) {
    leftFrontMotor.setVelocity(spd,rpm);
    rightFrontMotor.setVelocity(spd,rpm);
    rightBackMotor.setVelocity(spd,rpm);
    leftBackMotor.setVelocity(spd,rpm);

    leftFrontMotor.spinFor(reverse, amt, degrees);
    rightFrontMotor.spinFor(reverse, amt, degrees);
    rightBackMotor.spinFor(reverse, amt, degrees);
    leftBackMotor.spinFor(reverse, amt, degrees);
}

void makeTurnl(int amount, int speed)
{
  inertia.setRotation(0,degrees);
  
  while(inertia.rotation(degrees) > amount){
    leftFrontMotor.setVelocity(speed,rpm);
    rightFrontMotor.setVelocity(speed,rpm);
    rightBackMotor.setVelocity(speed,rpm);
    leftBackMotor.setVelocity(speed,rpm);

    leftFrontMotor.spin(fwd);
    rightFrontMotor.spin(reverse);
    rightBackMotor.spin(reverse);
    leftBackMotor.spin(fwd);
  }
}

void wings() {
  pneumatic = 1;
  pneu2 = 1;
}

void makeTurnr(int amount, int speed)
{
  inertia.setRotation(0,degrees);
  
  while(inertia.rotation(degrees) < amount){
    leftFrontMotor.setVelocity(speed,rpm);
    rightFrontMotor.setVelocity(speed,rpm);
    rightBackMotor.setVelocity(speed,rpm);
    leftBackMotor.setVelocity(speed,rpm);

    leftFrontMotor.spin(reverse);
    rightFrontMotor.spin(forward);
    rightBackMotor.spin(fwd);
    leftBackMotor.spin(reverse);
  }
}

void turnLT(float inchesFWD){
  float degreesFWD = inchesFWD * 3;
  leftFrontMotor.spinFor(reverse, degreesFWD, degrees, false);
  rightFrontMotor.spinFor(forward, degreesFWD, degrees, false);
  leftBackMotor.spinFor(reverse, degreesFWD, degrees, false);
  rightBackMotor.spinFor(fwd, degreesFWD, degrees, false);

}

void frwards(float inchesFWD){
  float degreesFWD = inchesFWD * 3;
  leftFrontMotor.setPosition(0, degrees);
while(leftFrontMotor.position(degrees)<degreesFWD){
  Brain.Screen.printAt(60, 40, "%f", fabs(leftFrontMotor.position(degrees)));
  leftFrontMotor.spin(fwd);
  rightFrontMotor.spin(fwd);
  leftBackMotor.spin(fwd);
  rightBackMotor.spin(fwd);
  catapult.spin(fwd, 100, pct);
}
leftBackMotor.stop();
leftFrontMotor.stop();
rightBackMotor.stop();
rightFrontMotor.stop();
}

void frward(float inchesFWD){
  float degreesFWD = inchesFWD * 3;
  leftFrontMotor.setPosition(0, degrees);
while(leftFrontMotor.position(degrees)<degreesFWD){
  leftFrontMotor.spin(fwd);
  rightFrontMotor.spin(fwd);
  leftBackMotor.spin(fwd);
  rightBackMotor.spin(fwd);
}
leftBackMotor.stop();
leftFrontMotor.stop();
rightBackMotor.stop();
rightFrontMotor.stop();
}



/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void matchautond(void) {
    wait(20,msec);
    intake.spin(reverse, 100, pct);
}

void skillsauton(void) {
    wait(20, msec);
    //fourpneu = 1;
    catapult.spin(fwd, 80, pct);
}

void skills(void) {
    wait(20, msec);
    setSpeed();
    //clearmotors();
    wait(1, sec);
    setSpeed();
    frwards(40);
   clearmotors();
    wings();
    turnLT(50);
    frward(10);
    turnLT(50);

    //clearmotors();
    //intake.spinFor(reverse, 50, degrees);
   // makeTurnr(45, 30);8 
    //drrev(200,40);
}


void matcho(void) {
//fwd 300 ms, turn 300 ms, full speed fwd

  leftFrontMotor.setVelocity(50,percent);
  rightFrontMotor.setVelocity(20, percent);
  leftBackMotor.setVelocity(50, percent);
  rightBackMotor.setVelocity(20, percent);

  leftFrontMotor.spin(reverse);
  rightFrontMotor.spin(reverse);
  leftBackMotor.spin(reverse);
  rightBackMotor.spin(reverse);

  wait(400, msec);

  leftFrontMotor.stop();
  rightFrontMotor.stop();
  leftBackMotor.stop();
  rightBackMotor.stop();

  wait(1000, msec);

  leftFrontMotor.spin(reverse);
  rightFrontMotor.spin(reverse);
  leftBackMotor.spin(reverse);
  rightBackMotor.spin(reverse);

    wait(1500, msec);


  leftFrontMotor.stop();
  rightFrontMotor.stop();
  leftBackMotor.stop();
  rightBackMotor.stop();

}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

bool toggleEnabled = false; // two-choice toggle, so we use bool
bool buttonPressed = false; // IGNORE, logic variable

bool toggleEnabled1 = false; // two-choice toggle, so we use bool
bool buttonPressed1 = false;

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
    wait(20, msec); // Sleep the task for a short amount of time to
    
    
  int fwdcont = Controller1.Axis3.position(percent) * 0.5;
  //int rightspeed = Controller1.Axis2.position(percent) * 0.7;
  int turncont = Controller1.Axis1.position(percent) * 0.5;
  //leftFrontMotor.spin(fwd, leftspeed, velocityUnits::pct);
  //leftBackMotor.spin(fwd, leftspeed, velocityUnits::pct);
  //leftTopMotor.spin(fwd, leftspeed, velocityUnits::pct);
  //rightFrontMotor.spin(fwd, rightspeed, velocityUnits::pct);
  //rightTopMotor.spin(fwd, rightspeed, velocityUnits::pct);
  //rightBackMotor.spin(fwd, rightspeed, velocityUnits::pct);
  leftFrontMotor.spin(fwd, fwdcont+turncont, velocityUnits::pct);
  rightFrontMotor.spin(fwd, fwdcont-turncont, velocityUnits::pct);
  leftBackMotor.spin(fwd, fwdcont+turncont, velocityUnits::pct);
  rightBackMotor.spin(fwd, fwdcont-turncont, velocityUnits::pct);
  //rightFrontMotor.spinFor(forward, 900, degrees);

   if(Controller1.ButtonL1.pressing()){
      intake.spin(forward, 100, pct);
    }
    else if(Controller1.ButtonL2.pressing()){
      intake.spin(reverse, 100, pct);
    }
    else{
      intake.stop();
    } 

    bool buttonx = Controller1.ButtonX.pressing();

    if (buttonx && !buttonPressed){
      buttonPressed = true; 
      toggleEnabled = !toggleEnabled;
    }
    else if (!buttonx) buttonPressed = false;

    if(toggleEnabled){
      catapult.spin(forward, 100, pct);
    }
    else{
      if(Controller1.ButtonR1.pressing()){
      catapult.spin(forward, 100, pct);
      }
      else if(Controller1.ButtonR2.pressing()){
      catapult.spin(reverse, 100, pct);
      }
      else{
      catapult.stop(hold);
      }
    }

 bool buttony = Controller1.ButtonRight.pressing();

    if (buttony && !buttonPressed1){
      buttonPressed1 = true; 
      toggleEnabled1 = !toggleEnabled1;
    }
    else if (!buttony) buttonPressed1 = false;

    if(toggleEnabled1){
            pneumatic = 1;
      pneu2 = 1;
    }
    else{
      pneumatic = 0;
      pneu2 = 0;
    }

    if (Controller1.ButtonLeft.pressing()){
      fourpneu = 1;
    }
    else {
      fourpneu = 0;
    }
                // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(matcho);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(20,msec);
}
}                                                                                                                       