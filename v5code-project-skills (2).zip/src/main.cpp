/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Controller1          controller                    
// rightFrontMotor      motor         19              
// leftFrontMotor       motor         18              
// rightBackMotor       motor         13              
// leftBackMotor        motor         14              
// rightTopMotor        motor         12              
// leftTopMotor         motor         11              
// intake               motor         16              
// catapult             motor         7               
// pneumatic            digital_out   A               
// pneu2                digital_out   B               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
    intake.spin(reverse);

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
  int fwdcont = Controller1.Axis3.position(percent) * 0.5;
  //int rightspeed = Controller1.Axis2.position(percent) * 0.7;
  int turncont = Controller1.Axis1.position(percent) * 0.5;
  //leftFrontMotor.spin(fwd, leftspeed, velocityUnits::pct);
  //leftBackMotor.spin(fwd, leftspeed, velocityUnits::pct);
  //leftTopMotor.spin(fwd, leftspeed, velocityUnits::pct);
  //rightFrontMotor.spin(fwd, rightspeed, velocityUnits::pct);
  //rightTopMotor.spin(fwd, rightspeed, velocityUnits::pct);
  //rightBackMotor.spin(fwd, rightspeed, velocityUnits::pct);
  leftFrontMotor.spin(fwd, fwdcont+turncont, velocityUnits::pct);
  rightFrontMotor.spin(fwd, fwdcont-turncont, velocityUnits::pct);
  leftBackMotor.spin(fwd, fwdcont+turncont, velocityUnits::pct);
  rightBackMotor.spin(fwd, fwdcont-turncont, velocityUnits::pct);


    if(Controller1.ButtonL1.pressing()){
      intake.spin(forward, 100, pct);
    }
    else if(Controller1.ButtonL2.pressing()){
      intake.spin(reverse, 100, pct);
    }
    else{
      intake.stop();
    }

    if(Controller1.ButtonR1.pressing()){
      catapult.spin(forward, 100, pct);
    }
    else if(Controller1.ButtonR2.pressing()){
      catapult.spin(reverse, 100, pct);
    }
    else{
      catapult.stop(hold);
    }

    if(Controller1.ButtonRight.pressing()){
      pneumatic = 1;
      pneu2 = 1;
    }
    else {
      pneumatic = 0;
      pneu2 = 0;
    }

}
}